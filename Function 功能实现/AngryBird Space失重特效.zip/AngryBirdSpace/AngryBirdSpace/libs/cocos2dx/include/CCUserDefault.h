/****************************************************************************
Copyright (c) 2010-2011 cocos2d-x.org

http://www.cocos2d-x.org

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
****************************************************************************/
#ifndef __SUPPORT_CCUSERDEFAULT_H__
#define __SUPPORT_CCUSERDEFAULT_H__

#include "CCPlatformMacros.h"

#include <string>
#include <libxml/parser.h>
#include <libxml/tree.h>
#include <libxml/xpath.h>
NS_CC_BEGIN;

/**
 * CCUserDefault acts as a tiny database. You can save and get base type values by it.
 * For example, setBoolForKey("played", true) will add a bool value true into the database.
 * Its key is "played". You can get the value of the key by getBoolForKey("played").
 * 
 * It supports the following base types:
 * bool, int, float, double, string
 */

// root name of xml
#define USERDEFAULT_ROOT_NAME	"userDefaultRoot"

#define XML_FILE_NAME   "UserDefault.xml"
#define ENXML_FILE_NAME "EncryptUserDefault.xml"
#define DEXML_FILE_NAME "DecryptUserDefault.xml"


class CC_DLL CCUserDefault
{
public:
	~CCUserDefault();

	// get value methods

  //Modify from cocos2d-x getXMLNodeForKey to myself getRootXMLNodeForKey to avoid the conflict with XmlInfo getRootXMLNodeForKey
  xmlNodePtr getRootXMLNodeForKey(const char* pDocFilePath,const char* pKey, xmlNodePtr *rootNode, xmlDocPtr *doc);
  inline const char* getValueForKey(const char* pKey);
  void setValueForKey(const char* pKey, const char* pValue);
	/**
	@brief Get bool value by key, if the key doesn't exist, a default value will return.
	 You can set the default value, or it is false.
	*/
	bool	getBoolForKey(const char* pKey, bool defaultValue = false);
	/**
	@brief Get integer value by key, if the key doesn't exist, a default value will return.
	 You can set the default value, or it is 0.
	*/
	int		getIntegerForKey(const char* pKey, int defaultValue = 0);
	/**
	@brief Get float value by key, if the key doesn't exist, a default value will return.
	 You can set the default value, or it is 0.0f.
	*/
	float	getFloatForKey(const char* pKey, float defaultValue=0.0f);
	/**
	@brief Get double value by key, if the key doesn't exist, a default value will return.
	 You can set the default value, or it is 0.0.
	*/
	double  getDoubleForKey(const char* pKey, double defaultValue=0.0);
	/**
	@brief Get string value by key, if the key doesn't exist, a default value will return.
	You can set the default value, or it is "".
	*/
	std::string getStringForKey(const char* pKey, const std::string & defaultValue = "");

	// set value methods

	/**
	@brief Set bool value by key.
	*/
	void	setBoolForKey(const char* pKey, bool value);
	/**
	@brief Set integer value by key.
	*/
	void	setIntegerForKey(const char* pKey, int value);
	/**
	@brief Set float value by key.
	*/
	void	setFloatForKey(const char* pKey, float value);
	/**
	@brief Set double value by key.
	*/
	void	setDoubleForKey(const char* pKey, double value);
	/**
	@brief Set string value by key.
	*/
	void	setStringForKey(const char* pKey, const std::string & value);

	static CCUserDefault* sharedUserDefault();
	static void purgeSharedUserDefault();
	const static std::string& getXMLFilePath();

private:
	CCUserDefault() {}
	static bool createXMLFile();
	static bool isXMLFileExist();
	static void initXMLFilePath();
	
	static CCUserDefault* m_spUserDefault;
	static std::string m_sFilePath;
	static bool m_sbIsFilePathInitialized;
};

NS_CC_END;

#endif // __SUPPORT_CCUSERDEFAULT_H__
