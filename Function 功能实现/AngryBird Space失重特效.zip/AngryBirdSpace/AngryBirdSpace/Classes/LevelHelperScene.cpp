//
//  LevelHelperScene.cpp
//  LevelHelperScene
//
//  Created by  on 3/19/12.
//  Copyright __MyCompanyName__ 2012. All rights reserved.
//
#include "LevelHelperScene.h"
#include "GLES-Render.h"
//#include "SingleData.h"

#define COCOS2D_DEBUG 1

const float FIXED_TIMESTEP = 1.0f / 60.0f;
const float MINIMUM_TIMESTEP = 1.0f / 600.0f;  
const int VELOCITY_ITERATIONS = 8;
const int POSITION_ITERATIONS = 8;
const int MAXIMUM_NUMBER_OF_STEPS = 25;

#define SLING_POSITION			ccp(60,157)
//#define SLING_BOMB_POSITION		ccpAdd(SLING_POSITION, ccp(0,9))
#define SLING_MAX_ANGLE			245
#define SLING_MIN_ANGLE			110
#define SLING_TOUCH_RADIUS		25
#define SLING_LAUNCH_RADIUS		25

CCScene* LevelHelperScene::scene()
{
  // 'scene' is an autorelease object
  CCScene *scene = CCScene::node();
  
  // add layer as a child to scene
  CCLayer* layer = new LevelHelperScene();
  scene->addChild(layer);
  layer->release();
  
  return scene;
}

LevelHelperScene::LevelHelperScene()
{
  initDataMember();
	setIsTouchEnabled( true );
	setIsAccelerometerEnabled( true );  
  
  
	CCSize screenSize = CCDirector::sharedDirector()->getWinSize();
	//UXLOG(L"Screen width %0.2f screen height %0.2f",screenSize.width,screenSize.height);
  
	// Define the gravity vector.
	b2Vec2 gravity;
	gravity.Set(0.0f, -2.0f);
	
	// Do we want to let bodies sleep?
	bool doSleep = true;
    
	// Construct a world object, which will hold and simulate the rigid bodies.
	world = new b2World(gravity);
  world->SetAllowSleeping(doSleep);    
	world->SetContinuousPhysics(true);
    
  
  m_debugDraw = new GLESDebugDraw();
  world->SetDebugDraw(m_debugDraw);
   
  int flags = 0;
  flags += b2Draw::e_shapeBit;
  flags += b2Draw::e_jointBit;
  flags += b2Draw::e_aabbBit;
  flags += b2Draw::e_pairBit;
  flags += b2Draw::e_centerOfMassBit;
  m_debugDraw->SetFlags(flags);		
  
  schedule( schedule_selector(LevelHelperScene::tick));
  
  schedule( schedule_selector(LevelHelperScene::updateGravity));
  
  this->initSprite();
  this->initLevelHelper();
  this->initMenu();


  this->initLHSprite();
  this->initCollisionHandling();
  this->setupNextBomb();
  

}

LevelHelperScene::~LevelHelperScene()
{
  delete m_pLevHelperLoader;
	delete world;
	world = NULL;
	
	delete m_debugDraw;
}

void LevelHelperScene::draw()
{
	// Default GL states: GL_TEXTURE_2D, GL_VERTEX_ARRAY, GL_COLOR_ARRAY, GL_TEXTURE_COORD_ARRAY
	// Needed states:  GL_VERTEX_ARRAY, 
	// Unneeded states: GL_TEXTURE_2D, GL_COLOR_ARRAY, GL_TEXTURE_COORD_ARRAY
  
	glDisable(GL_TEXTURE_2D);
	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	
	//world->DrawDebugData();
	
	// restore default GL states
	glEnable(GL_TEXTURE_2D);
	glEnableClientState(GL_COLOR_ARRAY);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);	
}

void LevelHelperScene::spriteMoveOnPathEnded(LHSprite* pLHSprite,std::string pathName)
{
}

void LevelHelperScene::spriteAnimHasEnded(LHSprite* pLHSprite,std::string animName)
{

}

void LevelHelperScene::initDataMember()
{
  m_pCurBird = NULL;
  m_pCurDynamicBird = NULL;
  m_pCurDynamicBird = NULL;
  m_intBubbleCollise = 0;
  m_intResetPos = 0;
  m_ftShift = 0;
  m_blResetPos = false;
  m_blBirdTouched = false;
  m_intDynamicBirdStatus = READY;
}

void LevelHelperScene::initMenu()
{
  /*
  LHSprite *pMenuSprite = m_pLevHelperLoader->spriteWithUniqueName("resetPress");
  pMenuSprite->registerTouchBeginObserver(this,callfuncO_selector(LevelHelperScene::touchBeginOnResetSprite));
  
  CCSize screenSize = CCDirector::sharedDirector()->getWinSize();

  CCMenuItemImage *pResetMenu = CCMenuItemImage::itemFromNormalImage("resetPress.png", "resetPress.png",this,menu_selector(LevelHelperScene::resetMenuCallback));
  pResetMenu->setPosition(ccp(60,screenSize.height-60));
  
  CCMenu *menu = CCMenu::menuWithItems(NULL);
  menu->setPosition(ccp(0,0));
  menu->addChild(pResetMenu,0);
  this->addChild(menu);
   */
}

void LevelHelperScene::touchBeginOnResetSprite(LHTouchInfo* info)
{
  resetScene();
}

void LevelHelperScene::initSprite()
{
}

void LevelHelperScene::initLHSprite()
{
  LHSprite *pLeve1Sprite = m_pLevHelperLoader->spriteWithUniqueName("btn_001_1");
  pLeve1Sprite->registerTouchBeginObserver(this, callfuncO_selector(LevelHelperScene::touchBeginOnLeve1Sprite));
  LHSprite *pLeve2Sprite = m_pLevHelperLoader->spriteWithUniqueName("btn_002_2");
  pLeve2Sprite->registerTouchBeginObserver(this, callfuncO_selector(LevelHelperScene::touchBeginOnLeve2Sprite));
}

void LevelHelperScene::initCollisionHandling()
{
  m_pLevHelperLoader->useLevelHelperCollisionHandling();
  m_pLevHelperLoader->registerBeginOrEndCollisionCallbackBetweenTagA(DYNAMICBIRD, ATMOSPHERE, this, callfuncO_selector(LevelHelperScene::birdBubbleCollision));
  m_pLevHelperLoader->registerBeginOrEndCollisionCallbackBetweenTagA(DYNAMICBIRD, GROUND, this, callfuncO_selector(LevelHelperScene::birdBoundaryCollision));
  m_pLevHelperLoader->registerBeginOrEndCollisionCallbackBetweenTagA(DYNAMICBIRD, DESTINATION, this, callfuncO_selector(LevelHelperScene::birdDestinationCollision));
}

void LevelHelperScene::cancelCollisionHandling()
{
  m_pLevHelperLoader->cancelBeginOrEndCollisionCallbackBetweenTagA(DYNAMICBIRD, ATMOSPHERE);
   m_pLevHelperLoader->cancelBeginOrEndCollisionCallbackBetweenTagA(DYNAMICBIRD, GROUND);
}

void LevelHelperScene::birdBubbleCollision(LHContactInfo* pContact)
{
  int intCollise = pContact->contactType;
  if (intCollise==1) {
    m_intBubbleCollise = 1;
    m_intDynamicBirdStatus = READY;
    //schedule( schedule_selector(LevelHelperScene::updateGravity));
  }
  else if(intCollise==0)
  {
    m_intBubbleCollise = 0;
    //unschedule( schedule_selector(LevelHelperScene::updateGravity));
  }
}

void LevelHelperScene::birdBoundaryCollision(LHContactInfo* pContact)
{
  int intCollise = pContact->contactType;
  if (intCollise==1) {
    m_pLevHelperLoader->markSpriteForRemoval(m_pCurDynamicBird);
    m_pCurDynamicBird = NULL;
    m_blResetPos = true;
    m_intDynamicBirdStatus = READY;
  }
  else if(intCollise==0)
  {

  }
}

void LevelHelperScene::birdDestinationCollision(LHContactInfo* pContact)
{
  int intCollise = pContact->contactType;
  if (intCollise==1) {
    m_pLevHelperLoader->markSpriteForRemoval(pContact->spriteA());
    m_pLevHelperLoader->markSpriteForRemoval(pContact->spriteB());
    m_pCurDynamicBird = NULL;

  }
  else if(intCollise==0)
  {
    
  }
}


void LevelHelperScene::updateGravity(ccTime dt)
{
  if (m_intBubbleCollise==3) {
    b2Body* pPlayerBody = m_pCurDynamicBird->getBody();
    CCPoint posStar = m_pLevHelperLoader->spriteWithUniqueName("img_planet_1")->getPosition();
    CCPoint posDynamicBird = m_pCurDynamicBird->getPosition();
    CCPoint posVec = ccpSub(posStar,posDynamicBird);
    b2Vec2 bubbleInnerGravity = b2Vec2(posVec.x/LHSettings::sharedInstance()->lhPtmRatio(),posVec.y/LHSettings::sharedInstance()->lhPtmRatio());
    //bubbleInnerGravity = b2Vec2(0,0);
    pPlayerBody->SetOwnGravity(bubbleInnerGravity);
    pPlayerBody->SetUseOwnGravity(true);
    b2Vec2 E = 0.2f * bubbleInnerGravity;
    pPlayerBody->ApplyForceToCenter(E);
    
    }
  
  
  for (b2Body* b = world->GetBodyList(); b; b = b->GetNext())
	{
		if (b->GetUserData() != NULL) {
			LHSprite* myActor = (LHSprite*)b->GetUserData();
      if (myActor->getTag()==DYNAMICBIRD||myActor->getTag()==GEAR||myActor->getTag()==DESTINATION) 
      {
        b2Body* groundBody = m_pLevHelperLoader->spriteWithUniqueName("img_planet_1")->getBody();
        b2Vec2 center = groundBody->GetPosition();
        b2Vec2 position = b->GetPosition();

        
        b2Vec2 d = center - position;
        if (d.LengthSquared() < 19)
        {
          d.Normalize();
          b2Vec2 F =  d;
          b->SetOwnGravity(F);
          b->SetUseOwnGravity(true);
          
          b->ApplyForceToCenter(F);
        }


      }
      else {
        continue;
      }
      
		}	
	}
  
}

void LevelHelperScene::tick(ccTime dt)
{
	//It is recommended that a fixed time step is used with Box2D for stability
	//of the simulation, however, we are using a variable time step here.
	//You need to make an informed choice, the following URL is useful
	//http://gafferongames.com/game-physics/fix-your-timestep/
	
  this->step(dt);
  
    
	// Instruct the world to perform a single step of simulation. It is
	// generally best to keep the time step and iterations fixed.
	//world->Step(dt, velocityIterations, positionIterations);
  
	for (b2Body* b = world->GetBodyList(); b; b = b->GetNext())
	{
		if (b->GetUserData() != NULL) {
			//Synchronize the AtlasSprites position and rotation with the corresponding body
			CCSprite* myActor = (CCSprite*)b->GetUserData();
      //if (myActor!=0) 
      {
        myActor->setRotation( -1 * CC_RADIANS_TO_DEGREES(b->GetAngle()) );
        myActor->setPosition(LevelHelperLoader::metersToPoints(b->GetPosition()));	
      }

		}	
	}
  
  CCPoint refPos;
  if (m_pCurDynamicBird) {
      refPos = m_pCurDynamicBird->getPosition();
  }
  else {
    LHSprite *pPlanetSprite = m_pLevHelperLoader->spriteWithUniqueName("img_planet_1");
    refPos = pPlanetSprite->getPosition();
  }

  

  
  CCSize screenSize = CCDirector::sharedDirector()->getWinSize();
  

  if(m_ftShift<0)
  {
    m_ftShift=0;
  }
  else if(m_ftShift>350)
  {
    m_ftShift=350;
  }
  
  if (m_intDynamicBirdStatus==READY) {
    if (m_ftShift>=0&&m_ftShift<=350) {
      this->getCamera()->setCenterXYZ(m_ftShift, 0, 0);
      this->getCamera()->setEyeXYZ(m_ftShift, 0, 1);

    }
  }
  else if(m_intDynamicBirdStatus==FLYING)
  {
    m_ftShift = refPos.x-screenSize.width/2+100;
    if (m_ftShift>=0&&m_ftShift<350) {
      this->getCamera()->setCenterXYZ(m_ftShift, 0, 0);
      this->getCamera()->setEyeXYZ(m_ftShift, 0, 1);
    }
  }

  m_pLevHelperLoader->removeMarkedSprites();
}

void LevelHelperScene::step(ccTime dt)
{
  float32 frameTime = dt;
	int stepsPerformed = 0;
	while ( (frameTime > 0.0) && (stepsPerformed < MAXIMUM_NUMBER_OF_STEPS) ){
		float32 deltaTime = std::min( frameTime, FIXED_TIMESTEP );
		frameTime -= deltaTime;
		if (frameTime < MINIMUM_TIMESTEP) {
			deltaTime += frameTime;
			frameTime = 0.0f;
		}
		world->Step(deltaTime,VELOCITY_ITERATIONS,POSITION_ITERATIONS);
		stepsPerformed++;
		this->afterStep(); // process collisions and result from callbacks called by the step
	}
	world->ClearForces ();
}

void LevelHelperScene::afterStep()
{
}

void LevelHelperScene::touchBeginOnLeve1Sprite(LHTouchInfo* info)
{
  CCUserDefault::sharedUserDefault()->setIntegerForKey("level", 1);
  CCDirector::sharedDirector()->replaceScene(LevelHelperScene::scene());
}

void LevelHelperScene::touchBeginOnLeve2Sprite(LHTouchInfo* info)
{
  CCUserDefault::sharedUserDefault()->setIntegerForKey("level", 2);
  CCDirector::sharedDirector()->replaceScene(LevelHelperScene::scene());
}

CCRect LevelHelperScene::rectInPixels(CCSprite *pSprite)
{
	CCSize s = pSprite->getContentSize();//pTexture->getContentSizeInPixels();
	return CCRectMake(pSprite->getPosition().x-s.width / 2, pSprite->getPosition().y-s.height / 2, s.width, s.height);
}

bool LevelHelperScene::containsTouchLocation(CCSprite *pSprite,CCPoint touchPos)
{
  if (pSprite) {
    CCRect r = this->rectInPixels(pSprite);
    return CCRect::CCRectContainsPoint(r, touchPos);
  }
  else {
    return false;
  }
}

void LevelHelperScene::ccTouchesBegan(CCSet* touches, CCEvent* event)
{
	//Add a new body/atlas sprite at the touched location
	CCSetIterator it;
	CCTouch* touch;
  int intTouchCount = 0;
  CCPoint location;
	for( it = touches->begin(); it != touches->end(); it++) 
	{
		touch = (CCTouch*)(*it);
    intTouchCount++;
		if(!touch)
			break;
    
		location = touch->locationInView(touch->view());
		
		location = CCDirector::sharedDirector()->convertToGL(location);
    
    m_blBirdTouched = this->containsTouchLocation(m_pCurBird,location);
    if (m_blBirdTouched) {
      SimpleAudioEngine::sharedEngine()->playEffect("slingshot streched.mp3");
    }
    
	}

  m_ptBegin = location;
}


void LevelHelperScene::setupNextBomb()
{
  CCArray* pArrayBirds = m_pLevHelperLoader->spritesWithTag(BIRD);
	if (0 < pArrayBirds->count())
	{
		m_pCurBird = (LHSprite*)pArrayBirds->objectAtIndex(0);
		
		//move it into position
    m_pCurBird->runAction(CCMoveTo::actionWithDuration(0.5f, this->slingBombPosition()));
    m_pCurBird->runAction(CCRotateTo::actionWithDuration(0.5f, 0));

  }
	else
  {
		m_pCurBird = NULL;
  }
}

CCPoint LevelHelperScene::slingBombPosition()
{
  LHSprite* sling = m_pLevHelperLoader->spriteWithUniqueName("img_tools2_sling1");
  CCPoint newPos = ccpAdd(sling->getPosition(), ccp(-10,30));
  return newPos;
}

void LevelHelperScene::ccTouchesMoved(CCSet* touches, CCEvent* event)
{
	//Add a new body/atlas sprite at the touched location
	CCSetIterator it;
	CCTouch* touch;
    CCPoint location;
	for( it = touches->begin(); it != touches->end(); it++) 
	{
		touch = (CCTouch*)(*it);
    
		if(!touch)
			break;
    
    location = touch->locationInView(touch->view());
    location = CCDirector::sharedDirector()->convertToGL(location);
    
    if (m_blBirdTouched) {

      
      CCPoint vector = ccpSub(location, this->slingBombPosition());
      CCPoint normalVector = ccpNormalize(vector);
      float angleRads = ccpToAngle(normalVector);
      int angleDegs = (int)CC_RADIANS_TO_DEGREES(angleRads) % 360;
      float length = ccpLength(vector);
      
      //Correct the Angle; we want a positive one
      while (angleDegs < 0)
        angleDegs += 360;
      
      //Limit the length
      if (length > SLING_LAUNCH_RADIUS)
        length = SLING_LAUNCH_RADIUS;
      
      //Limit the angle
      if (angleDegs > SLING_MAX_ANGLE)
        normalVector = ccpForAngle(CC_DEGREES_TO_RADIANS(SLING_MAX_ANGLE));
      else if (angleDegs < SLING_MIN_ANGLE)
        normalVector = ccpForAngle(CC_DEGREES_TO_RADIANS(SLING_MIN_ANGLE));
      
      //Set the position
      if(NULL != m_pCurBird)
      {
        CCPoint newPos = ccpAdd(this->slingBombPosition(), ccpMult(normalVector, length));
        m_pCurBird->setPosition(newPos);
      }
    }
    else {
      if (m_intDynamicBirdStatus != FLYING) {
        
          m_ftShift=m_ftShift-location.x+m_ptBegin.x;
      }

    }

            
    
	}
  

  
  m_ptPrevious = location;
}


void LevelHelperScene::ccTouchesEnded(CCSet* touches, CCEvent* event)
{
	//Add a new body/atlas sprite at the touched location
	CCSetIterator it;
	CCTouch* touch;
    CCPoint location;
	for( it = touches->begin(); it != touches->end(); it++) 
	{
		touch = (CCTouch*)(*it);
        
		if(!touch)
			break;
        
		location = touch->locationInView(touch->view());
		
		location = CCDirector::sharedDirector()->convertToGL(location);

      	CCPoint posVector;
        
        if (m_pCurBird&&m_blBirdTouched)
        {
            posVector = ccpSub(this->slingBombPosition(),  m_pCurBird->getPosition());

            
            LHSprite* pDynamicBird = m_pLevHelperLoader->newPhysicalSpriteWithUniqueName("abs_bird_dynamic");
            pDynamicBird->setPosition(m_pCurBird->getPosition());
            pDynamicBird->setIsVisible(true);
            pDynamicBird->setTag(DYNAMICBIRD);
            this->addChild(pDynamicBird);
            b2Body* bordBody = pDynamicBird->getBody();
            //b2Vec2 b2Position = b2Vec2(2.3,4.8);
            b2Vec2 b2Position = b2Vec2(this->slingBombPosition().x/LHSettings::sharedInstance()->lhPtmRatio(),this->slingBombPosition().y/LHSettings::sharedInstance()->lhPtmRatio());
            float32 b2Angle = -1 * CC_DEGREES_TO_RADIANS(pDynamicBird->getRotation());
          
            bordBody->SetTransform(b2Position, b2Angle);
          
            m_pLevHelperLoader->removeSprite(m_pCurBird);
            m_pCurDynamicBird = pDynamicBird;
          
          
          if(m_pCurDynamicBird == NULL)
            return;
          
          b2Body *pBirdBody = m_pCurDynamicBird->getBody();
          b2Vec2 impulseVec = b2Vec2(10,10);
          b2Vec2 posVec = b2Vec2((float)posVector.x,(float)posVector.y);
          pBirdBody->ApplyForceToCenter(posVec);
          m_blResetPos = false;
          m_intResetPos = 0;
          m_intDynamicBirdStatus = FLYING;
          SimpleAudioEngine::sharedEngine()->playEffect("redLaunch.mp3");
          this->setupNextBomb();

        }
        


    
	}
  

  
  m_ptPrevious = CCPointZero;
  m_ptLast = location;
  m_blBirdTouched = false;


}



void LevelHelperScene::resetMenuCallback(CCObject* pSender)
{
  CCDirector::sharedDirector()->replaceScene(LevelHelperScene::scene());
}

void LevelHelperScene::initLevelHelper()
{
  m_pLevHelperLoader->dontStretchArtOnIpad();
  int intLevel = CCUserDefault::sharedUserDefault()->getIntegerForKey("level");
  char charLevel[20];
  sprintf(charLevel, "abs_level%d.plhs",intLevel);
  std::string strLevel = CCFileUtils::fullPathFromRelativePath(charLevel);
  m_pLevHelperLoader = new LevelHelperLoader(strLevel.c_str());

  //notification have to be added before creating the objects
  //if you dont want notifications - it is better to remove this lines
  m_pLevHelperLoader->registerNotifierOnAllPathEndPoints(this,callfuncN_selector(LevelHelperScene::spriteMoveOnPathEnded));
  m_pLevHelperLoader->registerNotifierOnAllAnimationEnds(this,callfuncND_selector(LevelHelperScene::spriteAnimHasEnded));
  m_pLevHelperLoader->enableNotifOnLoopForeverAnimations();
  
  
  m_pLevHelperLoader->addObjectsToWorld(world, this);
  
  if (m_pLevHelperLoader->hasPhysicBoundaries()) {
    m_pLevHelperLoader->createPhysicBoundaries(world);
  }
  
  if (!m_pLevHelperLoader->isGravityZero()) {
    m_pLevHelperLoader->createGravity(world);
  }
}

void LevelHelperScene::resetScene()
{
  this->unschedule( schedule_selector(LevelHelperScene::tick) );
  this->cancelCollisionHandling();

  delete m_pLevHelperLoader;
  m_pLevHelperLoader = NULL;
  
  
  this->initDataMember();
  this->initLevelHelper();
  this->initMenu();
  this->initLHSprite();
  this->initCollisionHandling();
  this->setupNextBomb();
  this->schedule( schedule_selector(LevelHelperScene::tick) );
}

void LevelHelperScene::nexLevelDelegate()
{
  this->unschedule( schedule_selector(LevelHelperScene::tick) );
  delete m_pLevHelperLoader;
  m_pLevHelperLoader = NULL;
  
  this->initLevelHelper();
  this->initMenu();
  this->initLHSprite();
  this->initCollisionHandling();
  
  this->schedule( schedule_selector(LevelHelperScene::tick) );
}

void LevelHelperScene::restartDelegate()
{
  this->onEnter();
  this->resetScene();
}

void LevelHelperScene::levelsDelegate()
{
  CCDirector::sharedDirector()->replaceScene(LevelHelperScene::scene());
}
