//
//  LevelHelperScene.h
//  LevelHelperScene
//
//  Created by  on 3/19/12.
//  Copyright __MyCompanyName__ 2012. All rights reserved.
//
#ifndef __LEVEL_HELPER_SCENE_H__
#define __LEVEL_HELPER_SCENE_H__

// When you import this file, you import all the cocos2d classes
#include "cocos2d.h"
#include "Box2D.h"
#include "GLES-Render.h"
#include "SimpleAudioEngine.h"
#include "LevelHelper.h"

using namespace cocos2d;
using namespace CocosDenshion;

enum dynamicBirdStatus
{
  READY,
	FLYING,
	FLOATING
};

class LevelHelperScene : public CCLayer {
public:
    ~LevelHelperScene();
    LevelHelperScene();
    
    // returns a Scene that contains the HelloWorld as the only child
    static CCScene* scene();
    
    // adds a new sprite at a given coordinate
    virtual void draw();
    virtual void ccTouchesBegan(CCSet* touches,CCEvent* event);
    virtual void ccTouchesMoved(CCSet* touches,CCEvent* event);
    virtual void ccTouchesEnded(CCSet* touches,CCEvent* event);
    void touchBeginOnLeve1Sprite(LHTouchInfo* info);
    void touchBeginOnLeve2Sprite(LHTouchInfo* info);

    void tick(ccTime dt);
    void updateGravity(ccTime dt);
private:
    void step(ccTime dt);
    void afterStep();

    void initMenu();
    void initSprite();
    void initDataMember();
    void initLevelHelper();
    void initLHSprite();
    void initCollisionHandling();
    void cancelCollisionHandling();
    void birdBubbleCollision(LHContactInfo* pContact);
    void birdBoundaryCollision(LHContactInfo* pContact);
    void birdDestinationCollision(LHContactInfo* pContact);
  
    void resetScene();
    void spriteMoveOnPathEnded(LHSprite* pLHSprite,std::string pathName);
    void spriteAnimHasEnded(LHSprite* pLHSprite,std::string animName);
private:
    virtual void resetMenuCallback(CCObject* pSender);
    void touchBeginOnResetSprite(LHTouchInfo* info);
    bool containsTouchLocation(CCSprite *pSprite,CCPoint touchPos);
    CCRect rectInPixels(CCSprite *pSprite);
private:
    virtual void nexLevelDelegate();
    virtual void restartDelegate();
    virtual void levelsDelegate();
private:
    CCPoint slingBombPosition();
    void setupNextBomb();
private:
  LevelHelperLoader* m_pLevHelperLoader;
  b2World* world;
  GLESDebugDraw *m_debugDraw;
  b2MouseJoint* m_pMouseJoint;
  

  float	mfScaleX;
	float	mfScaleY;

  CCPoint m_ptBegin;
  CCPoint m_ptPrevious;
  CCPoint m_ptLast;
  

  LHSprite *m_pCurBird;
  LHSprite *m_pCurDynamicBird;

  int m_intBubbleCollise;
  bool m_blBirdTouched;
  bool m_blResetPos;
  int m_intResetPos;
  float m_ftShift;
  int m_intDynamicBirdStatus;
};

#endif // __LEVEL_HELPER_SCENE_H__
